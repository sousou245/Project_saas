document.addEventListener('DOMContentLoaded', function () {
    // DOM Elements
    const sidebar = document.getElementById('sidebar');
    const mobileOverlay = document.getElementById('mobile-overlay');
    const toggleSidebarBtn = document.getElementById('toggle-sidebar');
    const navItems = document.querySelectorAll('.nav-item a');
    const sections = document.querySelectorAll('.content-section');

    // Modals
    const userModalOverlay = document.getElementById('user-modal-overlay');
    const projectModalOverlay = document.getElementById('project-modal-overlay');
    const addUserBtn = document.getElementById('addUser');
    const addProjectBtn = document.getElementById('addProject');
    const closeUserModalBtn = document.getElementById('close-user-modal');
    const closeProjectModalBtn = document.getElementById('close-project-modal');
    const cancelUserBtn = document.getElementById('cancel-user');
    const cancelProjectBtn = document.getElementById('cancel-project');

    // Forms
    const userForm = document.getElementById('user-form');
    const projectForm = document.getElementById('project-form');

    // Tables
    const logsBody = document.getElementById('logs-body');
    const usersBody = document.getElementById('users-body');
    const projectsBody = document.getElementById('projects-body');

    // Search and Filter Elements
    const searchLogs = document.getElementById('search-logs');
    const filterType = document.getElementById('filter-type');
    const filterDate = document.getElementById('filter-date');
    const searchUsers = document.getElementById('search-users');
    const filterRole = document.getElementById('filter-role');
    const filterStatus = document.getElementById('filter-status');
    const searchProjects = document.getElementById('search-projects');
    const filterProjectStatus = document.getElementById('filter-project-status');

    // Export buttons
    const exportLogsBtn = document.getElementById('exportLogs');
    const exportAllLogsBtn = document.getElementById('exportAllLogs');

    // Pagination elements
    const paginationElements = document.querySelectorAll('.pagination .page-item');

    // Sample data for logs
    const logsData = [
        { date: '2025-03-03 09:34:21', user: 'admin@example.com', action: 'Connexion au système', status: 'success' },
        { date: '2025-03-03 08:15:42', user: 'john.doe@example.com', action: 'Création de projet', status: 'success' },
        { date: '2025-03-02 17:22:18', user: 'jane.smith@example.com', action: 'Modification de tâche', status: 'warning' },
        { date: '2025-03-02 14:05:36', user: 'michael.brown@example.com', action: 'Suppression de document', status: 'danger' },
        { date: '2025-03-02 11:47:53', user: 'sarah.wilson@example.com', action: 'Ajout d\'utilisateur', status: 'success' },
        { date: '2025-03-01 16:33:09', user: 'admin@example.com', action: 'Mise à jour système', status: 'info' }
    ];
    // async function 
    let usersData = [];

async function fetchUsers() {
    try {
        const response = await fetch("http://localhost:3000/api/users");
        usersData = await response.json();
        console.log("Données récupérées :", usersData);
        renderUsers(usersData); // Appelle la fonction pour afficher les utilisateurs
        return usersData;
    } catch (error) {
        console.error("Erreur:", error);
    }

}

// Appel de la fonction pour récupérer les utilisateurs
fetchUsers();
    // Toggle Sidebar
    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', function () {
            sidebar.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
        });
    }

    if (mobileOverlay) {
        mobileOverlay.addEventListener('click', function () {
            sidebar.classList.remove('active');
            mobileOverlay.classList.remove('active');
        });
    }

    // Navigation
    navItems.forEach(item => {
        item.addEventListener('click', function (e) {
            e.preventDefault();
            const targetSection = this.getAttribute('data-section');

            // Update active nav item
            document.querySelectorAll('.nav-item').forEach(navItem => {
                navItem.classList.remove('active');
            });
            this.parentElement.classList.add('active');

            // Show target section
            sections.forEach(section => {
                section.style.display = 'none';
                section.classList.remove('active-section');
            });

            if (targetSection === 'logout') {
                // Handle logout
                alert('Déconnexion en cours...');
                return;
            }

            const sectionToShow = document.getElementById(`${targetSection}-section`);
            if (sectionToShow) {
                sectionToShow.style.display = 'block';
                sectionToShow.classList.add('active-section');
            } else {
                document.getElementById('dashboard-section').style.display = 'block';
                document.getElementById('dashboard-section').classList.add('active-section');
            }

            // Close sidebar on mobile
            if (window.innerWidth <= 1024) {
                sidebar.classList.remove('active');
                mobileOverlay.classList.remove('active');
            }
        });
    });

    // Modal functions
    function openModal(modalOverlay) {
        if (modalOverlay) {
            modalOverlay.classList.add('active');
        }
    }

    function closeModal(modalOverlay) {
        if (modalOverlay) {
            modalOverlay.classList.remove('active');
        }
    }

    // Add User Modal
    if (addUserBtn) {
        addUserBtn.addEventListener('click', function () {
            openModal(userModalOverlay);
        });
    }

    if (closeUserModalBtn) {
        closeUserModalBtn.addEventListener('click', function () {
            closeModal(userModalOverlay);
        });
    }

    if (cancelUserBtn) {
        cancelUserBtn.addEventListener('click', function () {
            closeModal(userModalOverlay);
        });
    }

    // Add Project Modal
    if (addProjectBtn) {
        addProjectBtn.addEventListener('click', function () {
            openModal(projectModalOverlay);
        });
    }

    if (closeProjectModalBtn) {
        closeProjectModalBtn.addEventListener('click', function () {
            closeModal(projectModalOverlay);
        });
    }

    if (cancelProjectBtn) {
        cancelProjectBtn.addEventListener('click', function () {
            closeModal(projectModalOverlay);
        });
    }

    // Form submissions
    if (userForm) {
        userForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const name = document.getElementById('user-name').value;
            const email = document.getElementById('user-email').value;
            const role = document.getElementById('user-role').value;
            const status = document.getElementById('user-status').value;

            // Add user to data
            usersData.unshift({
                name: name,
                email: email,
                role: role,
                status: status,
                date: new Date().toISOString().split('T')[0]
            });

            // Update users table
            populateUsersTable();

            // Add log entry
            logsData.unshift({
                date: new Date().toLocaleString('fr-FR').replace(',', ''),
                user: 'admin@example.com',
                action: `Ajout d'utilisateur: ${name}`,
                status: 'success'
            });

            // Update logs table
            populateLogsTable();

            // Update counters
            updateCounters();

            alert(`Utilisateur ajouté: ${name}, ${email}, ${role}, ${status}`);
            closeModal(userModalOverlay);
            userForm.reset();
        });
    }

    if (projectForm) {
        projectForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const name = document.getElementById('project-name').value;
            const manager = document.getElementById('project-manager').value;
            const status = document.getElementById('project-status').value;
            const start = document.getElementById('project-start').value;
            const end = document.getElementById('project-end').value;

            // Add project to data
            projectsData.unshift({
                name: name,
                manager: manager,
                status: status,
                start: start,
                end: end
            });

            // Update projects table
            populateProjectsTable();

            // Add log entry
            logsData.unshift({
                date: new Date().toLocaleString('fr-FR').replace(',', ''),
                user: 'admin@example.com',
                action: `Création de projet: ${name}`,
                status: 'success'
            });

            // Update logs table
            populateLogsTable();

            // Update counters
            updateCounters();

            alert(`Projet ajouté: ${name}, ${manager}, ${status}, ${start}, ${end}`);
            closeModal(projectModalOverlay);
            projectForm.reset();
        });
    }

    // Search and Filter functions
    function setupSearchAndFilters() {
        if (searchLogs) {
            searchLogs.addEventListener('input', function () {
                filterLogs();
            });
        }

        if (filterType) {
            filterType.addEventListener('change', function () {
                filterLogs();
            });
        }

        if (filterDate) {
            filterDate.addEventListener('change', function () {
                filterLogs();
            });
        }

        if (searchUsers) {
            searchUsers.addEventListener('input', function () {
                filterUsers();
            });
        }

        if (filterRole) {
            filterRole.addEventListener('change', function () {
                filterUsers();
            });
        }

        if (filterStatus) {
            filterStatus.addEventListener('change', function () {
                filterUsers();
            });
        }

        if (searchProjects) {
            searchProjects.addEventListener('input', function () {
                filterProjects();
            });
        }

        if (filterProjectStatus) {
            filterProjectStatus.addEventListener('change', function () {
                filterProjects();
            });
        }
    }

    function filterLogs() {
        if (!logsBody) return;

        const searchTerm = searchLogs.value.toLowerCase();
        const typeFilter = filterType.value;
        const dateFilter = filterDate.value;

        const filteredLogs = logsData.filter(log => {
            // Search term filter
            const matchesSearch =
                log.user.toLowerCase().includes(searchTerm) ||
                log.action.toLowerCase().includes(searchTerm);

            // Type filter
            let matchesType = true;
            if (typeFilter !== 'all') {
                if (typeFilter === 'user') matchesType = log.action.includes('utilisateur');
                else if (typeFilter === 'project') matchesType = log.action.includes('projet');
                else if (typeFilter === 'task') matchesType = log.action.includes('tâche');
                else if (typeFilter === 'payment') matchesType = log.action.includes('paiement');
            }

            // Date filter
            let matchesDate = true;
            if (dateFilter !== 'all') {
                const logDate = new Date(log.date.split(' ')[0]);
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                if (dateFilter === 'today') {
                    matchesDate = logDate.getTime() === today.getTime();
                } else if (dateFilter === 'week') {
                    const weekAgo = new Date();
                    weekAgo.setDate(today.getDate() - 7);
                    matchesDate = logDate >= weekAgo;
                } else if (dateFilter === 'month') {
                    const monthAgo = new Date();
                    monthAgo.setMonth(today.getMonth() - 1);
                    matchesDate = logDate >= monthAgo;
                }
            }

            return matchesSearch && matchesType && matchesDate;
        });

        renderLogs(filteredLogs);
    }

    function filterUsers() {
        if (!usersBody) return;

        const searchTerm = searchUsers.value.toLowerCase();
        const roleFilter = filterRole.value;
        const statusFilter = filterStatus.value;

        const filteredUsers = usersData.filter(user => {
            // Search term filter
            const matchesSearch =
                user.name.toLowerCase().includes(searchTerm) ||
                user.email.toLowerCase().includes(searchTerm);

            // Role filter
            const matchesRole = roleFilter === 'all' || user.role === roleFilter;

            // Status filter
            const matchesStatus = statusFilter === 'all' || user.status === statusFilter;

            return matchesSearch && matchesRole && matchesStatus;
        });

        renderUsers(filteredUsers);
    }

    function filterProjects() {
        if (!projectsBody) return;

        const searchTerm = searchProjects.value.toLowerCase();
        const statusFilter = filterProjectStatus.value;

        const filteredProjects = projectsData.filter(project => {
            // Search term filter
            const matchesSearch =
                project.name.toLowerCase().includes(searchTerm) ||
                project.manager.toLowerCase().includes(searchTerm);

            // Status filter
            const matchesStatus = statusFilter === 'all' || project.status === statusFilter;

            return matchesSearch && matchesStatus;
        });

        renderProjects(filteredProjects);
    }

    // Render functions for filtered data
    function renderLogs(logs) {
        if (!logsBody) return;

        logsBody.innerHTML = '';
        if (logs.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="5" class="empty-table">Aucun log ne correspond aux critères de recherche</td>';
            logsBody.appendChild(row);
            return;
        }

        logs.forEach(log => {
            const row = document.createElement('tr');

            // Status class
            let statusClass = 'status-info';
            if (log.status === 'success') statusClass = 'status-success';
            if (log.status === 'warning') statusClass = 'status-warning';
            if (log.status === 'danger') statusClass = 'status-danger';

            row.innerHTML = `
                <td>${log.date}</td>
                <td>${log.user}</td>
                <td>${log.action}</td>
                <td class="td-status">
                    <span class="status-indicator ${statusClass}"></span>
                    <span class="status-label">${log.status}</span>
                </td>
                <td class="action-cell">
                    <button class="action-btn view-btn" title="Voir les détails">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn delete-btn" title="Supprimer">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;

            logsBody.appendChild(row);
        });

        // Add event listeners for action buttons
        addLogActionListeners();
    }

    function renderUsers(users) {
        if (!usersBody) return;
    
        usersBody.innerHTML = '';
        if (users.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="6" class="empty-table">Aucun utilisateur ne correspond aux critères de recherche</td>';
            usersBody.appendChild(row);
            return;
        }
    
        users.forEach(user => {
            const row = document.createElement('tr');
            const date = new Date(user.created_at).toLocaleString('fr-FR');
            let statusClass = 'status-info';
            if (user.status === 'active') statusClass = 'status-success';
            if (user.status === 'inactive') statusClass = 'status-danger';
            if (user.status === 'pending') statusClass = 'status-warning';
    
            row.innerHTML = `
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>

                <td>${date}</td>
                <td class="action-cell">
                    <button class="action-btn edit-btn" title="Modifier">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" title="Supprimer">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
    
            usersBody.appendChild(row);
        });
    
        // Ajout des écouteurs d'événements
        addUserActionListeners();
    }

    function renderProjects(projects) {
        if (!projectsBody) return;

        projectsBody.innerHTML = '';
        if (projects.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="6" class="empty-table">Aucun projet ne correspond aux critères de recherche</td>';
            projectsBody.appendChild(row);
            return;
        }

        projects.forEach(project => {
            const row = document.createElement('tr');

            // Status class
            let statusClass = 'status-info';
            if (project.status === 'active') statusClass = 'status-success';
            if (project.status === 'completed') statusClass = 'status-info';
            if (project.status === 'on-hold') statusClass = 'status-warning';

            row.innerHTML = `
                <td>${project.name}</td>
                <td>${project.manager}</td>
                <td class="td-alignement">
                    <td class="td-status">
                        <span class="status-indicator ${statusClass}"></span>
                        <span class="status-label">${project.status}</span>
                    </td>
                    <td>${project.start}</td>
                    <td>${project.end}</td>
                    <td class="action-cell">
                        <button class="action-btn view-btn" title="Voir les détails">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit-btn" title="Modifier">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete-btn" title="Supprimer">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </td>
                </td>
            `;

            projectsBody.appendChild(row);
        });

        // Add event listeners for action buttons
        addProjectActionListeners();
    }

    // Add action listeners to table rows
    function addLogActionListeners() {
        const viewBtns = document.querySelectorAll('#logs-body .view-btn');
        const deleteBtns = document.querySelectorAll('#logs-body .delete-btn');

        viewBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const log = logsData[index];
                alert(`Détails du log:\nDate: ${log.date}\nUtilisateur: ${log.user}\nAction: ${log.action}\nStatut: ${log.status}`);
            });
        });

        deleteBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                if (confirm('Êtes-vous sûr de vouloir supprimer ce log?')) {
                    logsData.splice(index, 1);
                    populateLogsTable();
                }
            });
        });
    }

    function addUserActionListeners() {
        const editBtns = document.querySelectorAll('#users-body .edit-btn');
        const deleteBtns = document.querySelectorAll('#users-body .delete-btn');

        editBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const user = usersData[index];
                alert(`Modifier l'utilisateur:\nNom: ${user.name}\nEmail: ${user.email}\nRôle: ${user.role}\nStatut: ${user.status}`);
                // Here you would populate the user edit form and show it
            });
        });

        deleteBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const user = usersData[index];
                if (confirm(`Êtes-vous sûr de vouloir supprimer l'utilisateur ${user.name}?`)) {
                    usersData.splice(index, 1);
                    populateUsersTable();

                    // Add log entry
                    logsData.unshift({
                        date: new Date().toLocaleString('fr-FR').replace(',', ''),
                        user: 'admin@example.com',
                        action: `Suppression d'utilisateur: ${user.name}`,
                        status: 'danger'
                    });

                    // Update logs table
                    populateLogsTable();

                    // Update counters
                    updateCounters();
                }
            });
        });
    }

    function addProjectActionListeners() {
        const viewBtns = document.querySelectorAll('#projects-body .view-btn');
        const editBtns = document.querySelectorAll('#projects-body .edit-btn');
        const deleteBtns = document.querySelectorAll('#projects-body .delete-btn');

        viewBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const project = projectsData[index];
                alert(`Détails du projet:\nNom: ${project.name}\nManager: ${project.manager}\nStatut: ${project.status}\nDébut: ${project.start}\nFin: ${project.end}`);
            });
        });

        editBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const project = projectsData[index];
                alert(`Modifier le projet:\nNom: ${project.name}\nManager: ${project.manager}\nStatut: ${project.status}\nDébut: ${project.start}\nFin: ${project.end}`);
                // Here you would populate the project edit form and show it
            });
        });

        deleteBtns.forEach((btn, index) => {
            btn.addEventListener('click', function () {
                const project = projectsData[index];
                if (confirm(`Êtes-vous sûr de vouloir supprimer le projet ${project.name}?`)) {
                    projectsData.splice(index, 1);
                    populateProjectsTable();

                    // Add log entry
                    logsData.unshift({
                        date: new Date().toLocaleString('fr-FR').replace(',', ''),
                        user: 'admin@example.com',
                        action: `Suppression de projet: ${project.name}`,
                        status: 'danger'
                    });

                    // Update logs table
                    populateLogsTable();

                    // Update counters
                    updateCounters();
                }
            });
        });
    }

    // Populate Project Manager select
    function populateProjectManagerSelect() {
        const projectManager = document.getElementById('project-manager');
        if (projectManager) {
            projectManager.innerHTML = '<option value="">Sélectionner un chef de projet</option>';
            usersData.forEach(user => {
                if (user.status === 'active') {
                    const option = document.createElement('option');
                    option.value = user.name;
                    option.textContent = user.name;
                    projectManager.appendChild(option);
                }
            });
        }
    }



    // fetch pour les projets
    let projectsData = [];
    
    async function fetchProjects() {
        try {
            const response = await fetch("http://localhost:3000/api/projects");
            projectsData = await response.json();
            console.log("Données récupérées :", projectsData);
            renderProjects(projectsData); // Appelle la fonction pour afficher les projets
            return projectsData;
        } catch (error) {
            console.error("Erreur:", error);
        }
    }

    // Update dashboard counters
    async function updateCounters() {
        const totalUsers = document.getElementById('total-users');
        const totalProjects = document.getElementById('total-projects');
        const totalchef = document.getElementById('total-tasks');
        const totalPayments = document.getElementById('total-payments');
        // recuperer la valeur de usersData
        await fetchUsers()
        await fetchProjects()

        console.log(usersData)
        if (totalUsers) totalUsers.textContent = usersData.length;
        
        if (totalProjects) totalProjects.textContent = projectsData.length;
        //juste les chefs de projets 
        console.log(usersData.filter(user => user.role === 'chef').length)
        if (totalchef) totalchef.textContent = usersData.filter(user => user.role === 'chef').length;
        if (totalPayments) totalPayments.textContent = '0'; // This would be dynamic in a real app
    }

    // Export functionality
    function setupExportButtons() {
        if (exportLogsBtn) {
            exportLogsBtn.addEventListener('click', function () {
                exportLogs(logsData.slice(0, 10));
            });
        }

        if (exportAllLogsBtn) {
            exportAllLogsBtn.addEventListener('click', function () {
                exportLogs(logsData);
            });
        }
    }

    function exportLogs(logs) {
        // Convert logs to CSV
        const headers = ['Date', 'Utilisateur', 'Action', 'Statut'];
        let csv = headers.join(',') + '\n';

        logs.forEach(log => {
            const row = [
                `"${log.date}"`,
                `"${log.user}"`,
                `"${log.action}"`,
                `"${log.status}"`
            ];
            csv += row.join(',') + '\n';
        });

        // Create download link
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', 'logs_export.csv');
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    // Pagination functionality
    function setupPagination() {
        paginationElements.forEach(item => {
            item.addEventListener('click', function () {
                if (this.classList.contains('disabled')) return;

                const activePage = document.querySelector('.pagination .active');
                if (activePage) activePage.classList.remove('active');

                if (!this.classList.contains('disabled')) {
                    this.classList.add('active');
                }

                // In a real app, this would load the appropriate page of data
                alert('Chargement de la page ' + this.textContent);
            });
        });
    }

    // Initialize tables
    function populateLogsTable() {
        if (logsBody) {
            renderLogs(logsData);
        }
    }

    function populateUsersTable() {
        if (usersBody) {
            renderUsers(usersData);
        }
        populateProjectManagerSelect();
    }

    function populateProjectsTable() {
        if (projectsBody) {
            renderProjects(projectsData);
        }
    }
    // Function to fetch and display admin logs
    function displayAdminLogs() {
        const logsBody = document.getElementById('logs-body');
        if (!logsBody) return;

        // Show loading indicator
        logsBody.innerHTML = '<tr><td colspan="5" class="text-center">Chargement des logs administrateurs...</td></tr>';

        // Fetch admin logs from API
        fetch("http://localhost:3000/api/logs")
            .then((response) => {
                if (!response.ok) {
                    throw new Error('Erreur lors de la récupération des logs administrateurs');
                }
                return response.json();
            })
            .then((data) => {
                console.log(data)
                renderAdminLogs(data);
            })
            .catch((error) => {
                console.error("Erreur:", error);
                logsBody.innerHTML = `<tr><td colspan="5" class="text-center">Erreur: ${error.message}</td></tr>`;
            });
    }

    // Render admin logs to table
    function renderAdminLogs(logs) {
        const logsBody = document.getElementById('logs-body');
        if (!logsBody) return;

        logsBody.innerHTML = '';

        if (logs.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="5" class="empty-table">Aucun log administrateur trouvé</td>';
            logsBody.appendChild(row);
            return;
        }

        logs.forEach(log => {
            const row = document.createElement('tr');

            // Determine status class based on action
            let statusClass = 'status-info';
            let status = 'info';

            if (log.action.includes('ajout') || log.action.includes('création')) {
                statusClass = 'status-success';
                status = 'success';
            } else if (log.action.includes('suppression')) {
                statusClass = 'status-danger';
                status = 'danger';
            } else if (log.action.includes('modification')) {
                statusClass = 'status-warning';
                status = 'warning';
            }

            // Format date
            const date = new Date(log.createdAt).toLocaleString('fr-FR');

            row.innerHTML = `
        <td>${date}</td>
        <td>${log.user_id}</td>
        <td>${log.log_description}</td>
        <td class="td-status">
          <span class="status-indicator ${statusClass}"></span>
          <span class="status-label">${status}</span>
        </td>
        <td class="action-cell">
          <button class="action-btn view-btn" title="Voir les détails">
            <i class="fas fa-eye"></i>
          </button>
          <button class="action-btn delete-btn" title="Supprimer">
            <i class="fas fa-trash-alt"></i>
          </button>
        </td>
      `;

            logsBody.appendChild(row);
        });

        // Add event listeners for action buttons
        addLogActionListeners();
    }

    // Add a filter option for admin logs
    function addAdminLogsFilter() {
        const filterType = document.getElementById('filter-type');
        if (filterType) {
            // Check if option already exists
            if (!document.querySelector('option[value="admin"]')) {
                const option = document.createElement('option');
                option.value = 'admin';
                option.textContent = 'Logs administrateurs';
                filterType.appendChild(option);
            }

            // Event listener to handle admin log filtering
            filterType.addEventListener('change', function () {
                if (this.value === 'admin') {
                    displayAdminLogs();
                }
            });
        }
    }

    // Add admin log button to the logs section
    function addAdminLogsButton() {
        const logsHeader = document.querySelector('#logs-section .section-header');
        if (logsHeader) {
            const adminLogsBtn = document.createElement('button');
            adminLogsBtn.className = 'btn btn-primary ml-2';
            adminLogsBtn.id = 'displayAdminLogs';
            adminLogsBtn.innerHTML = '<i class="fas fa-shield-alt"></i> Afficher logs admin';

            // Insert before the export buttons
            const exportBtn = document.getElementById('exportLogs');
            if (exportBtn) {
                logsHeader.insertBefore(adminLogsBtn, exportBtn);
            } else {
                logsHeader.appendChild(adminLogsBtn);
            }

            // Add event listener
            adminLogsBtn.addEventListener('click', displayAdminLogs);
        }
    }

    // Add this to the init function in your main script
    document.addEventListener('DOMContentLoaded', function () {
        // Your existing code...

        // Add the admin logs functionality
        addAdminLogsFilter();
        addAdminLogsButton();

    });

    // Backend route in your Express.js server
    // Add this to your routes file or create a new route


    

    // Helper function to get admin user IDs
    async function getUserIdsWithAdminRole() {
        const User = require('../models/User'); // Adjust path as needed
        try {
            const adminUsers = await User.findAll({
                where: { role: 'admin' }
            });
            return adminUsers.map(user => user.id);
        } catch (error) {
            console.error('Error fetching admin users:', error);
            return [];
        }
    }





    function init() {
        populateLogsTable();
        populateUsersTable();
        populateProjectsTable();
        setupSearchAndFilters();
        setupExportButtons();
        setupPagination();
        updateCounters();
        displayAdminLogs();
    }

    init();
});