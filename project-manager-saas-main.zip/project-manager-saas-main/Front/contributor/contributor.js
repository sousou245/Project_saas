document.addEventListener('DOMContentLoaded', function () {
    // DOM Elements
    const sidebar = document.getElementById('sidebar');
    const mobileOverlay = document.getElementById('mobileOverlay');
    const toggleSidebarBtn = document.getElementById('toggleSidebar');
    const addTaskBtn = document.getElementById('addTaskBtn');
    const closeTaskModal = document.getElementById('closeTaskModal');
    const cancelTaskBtn = document.getElementById('cancelTaskBtn');
    const taskModal = document.getElementById('taskModal');
    const taskForm = document.getElementById('taskForm');
    const searchInput = document.querySelector('.search-box input');
    const filterSelects = document.querySelectorAll('.filter-select');
    const paginationItems = document.querySelectorAll('.pagination .page-item');
    const navItems = document.querySelectorAll('.nav-item');
    const mainContent = document.querySelector('.main-content');





    // Données des tâches (simulées)
    let tasks = [
        { id: 1, title: "Créer la maquette du dashboard", project: "Application Web", priority: "Haute", status: "En cours", dueDate: "2025-03-22", description: "Concevoir une interface utilisateur intuitive pour le tableau de bord principal." },
        { id: 2, title: "Développer l'API de connexion", project: "Application Web", priority: "Moyenne", status: "Terminé", dueDate: "2025-03-18", description: "Implémenter l'authentification OAuth2 pour l'API REST." },
        { id: 3, title: "Corriger les bugs d'affichage", project: "Application Mobile", priority: "Basse", status: "À faire", dueDate: "2025-03-25", description: "Résoudre les problèmes d'affichage sur les appareils Android à petit écran." },
        { id: 4, title: "Tester le formulaire d'inscription", project: "Application Web", priority: "Moyenne", status: "En cours", dueDate: "2025-03-20", description: "Effectuer des tests de validation et de sécurité sur le formulaire d'inscription." }
    ];

    // ... (previous code remains the same)
    // Function to create a new task
    // Modifier la fonction createNewTask pour qu'elle accepte les données de tâche en paramètre
    async function createNewTask(taskData) {
        try {
            // Envoyer la requête POST à l'API
            const response = await fetch('/api/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(taskData)
            });

            if (!response.ok) {
                throw new Error(`Erreur: ${response.status}`);
            }

            const createdTask = await response.json();

            // Rafraîchir l'affichage des tâches
            filterTasks();

            return createdTask;
        } catch (error) {
            console.error('Erreur lors de la création de la tâche:', error);
            throw error;
        }
    }
    // Fonction pour rendre les tâches dans le tableau
    async function renderTasks(projectId = null) {
        try {
            let taskList;

            if (projectId) {
                // Utiliser l'API pour récupérer les tâches d'un projet spécifique
                const response = await fetch(`/api/projects/${projectId}/tasks`);
                if (!response.ok) {
                    throw new Error('Erreur lors de la récupération des tâches');
                }
                taskList = await response.json();
            } else {
                // Si aucun projectId n'est fourni, utiliser toutes les tâches locales
                taskList = tasks;
            }

            const tbody = document.getElementById('tasksTableBody');
            if (!tbody) return; // Protection contre les erreurs

            tbody.innerHTML = '';

            if (taskList.length === 0) {
                const tr = document.createElement('tr');
                tr.innerHTML = '<td colspan="6" class="text-center">Aucune tâche trouvée</td>';
                tbody.appendChild(tr);
                return;
            }

            taskList.forEach(task => {
                const tr = document.createElement('tr');

                // Déterminer les classes CSS selon la priorité et le statut
                let priorityClass = task.priority === "Haute" ? 'status-danger' :
                    task.priority === "Moyenne" ? 'status-warning' : 'status-info';

                let statusClass = task.status === "pending" ? 'status-info' :
                    task.status === "in-progress" ? 'status-warning' :
                        task.status === "review" ? 'status-primary' : 'status-success';

                // Formatter la date pour l'affichage
                const formattedDate = task.due_date
                    ? new Date(task.due_date).toLocaleDateString('fr-FR')
                    : 'Non définie';

                tr.innerHTML = `
                <td>${task.title}</td>
                <td>${task.Project?.name || 'Non assigné'}</td>
                <td>
                    <span class="td-status">
                        <span class="status-indicator ${priorityClass}"></span>
                        <span class="status-label">${task.priority || 'Non définie'}</span>
                    </span>
                </td>
                <td>
                    <span class="td-status">
                        <span class="status-indicator ${statusClass}"></span>
                        <span class="status-label">${getStatusLabel(task.status)}</span>
                    </span>
                </td>
                <td>${formattedDate}</td>
                <td class="action-cell">
                    <button class="action-btn view-btn" data-task-id="${task.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn edit-btn" data-task-id="${task.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" data-task-id="${task.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;

                tbody.appendChild(tr);
            });

            attachTaskEventListeners();
        } catch (error) {
            console.error('Erreur lors du chargement des tâches:', error);
            const tbody = document.getElementById('tasksTableBody');
            if (tbody) {
                tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger">
                        Impossible de charger les tâches. ${error.message}
                    </td>
                </tr>
            `;
            }
        }
    }

    // Fonction utilitaire pour convertir les statuts
    function getStatusLabel(status) {
        const statusMap = {
            'pending': 'À faire',
            'in-progress': 'En cours',
            'review': 'En revue',
            'completed': 'Terminé'
        };
        return statusMap[status] || status;
    }
    // Modifier la fonction de filtrage pour supporter la recherche côté client
    // Dans la fonction filterTasks, assurez-vous d'appeler renderTasks correctement
    function filterTasks() {
        const searchTerm = document.querySelector('.search-box input').value.toLowerCase();
        const projectFilter = document.getElementById('projectFilter')?.value || 'all';
        const statusFilter = document.getElementById('statusFilter')?.value || 'all';

        // Si vous avez un projectId, passez-le à renderTasks
        let projectId = null;
        if (projectFilter !== 'all') {
            // Convertir le nom du projet en ID
            const projectName = projectFilter.replace(/-/g, ' ');
            const project = projects.find(p => p.name.toLowerCase() === projectName);
            if (project) {
                projectId = project.id;
            }
        }

        // Appeler renderTasks avec l'ID du projet
        renderTasks(projectId);
    }

    // Mettre à jour la création et la mise à jour de tâches pour utiliser l'API
    async function saveTask(taskData, isUpdate = false) {
        try {
            const url = isUpdate
                ? `/api/tasks/${currentTaskId}`
                : '/api/tasks';

            const method = isUpdate ? 'PUT' : 'POST';

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(taskData)
            });

            if (!response.ok) {
                throw new Error('Erreur lors de la sauvegarde de la tâche');
            }

            const savedTask = await response.json();

            // Fermer la modal et rafraîchir l'affichage
            closeTaskModalFn();
            filterTasks();

            return savedTask;
        } catch (error) {
            console.error('Erreur:', error);
            alert(`Erreur: ${error.message}`);
        }
    }

    // Modifier le gestionnaire de soumission du formulaire
    // Modify the existing task form submission handler
    // Remplacer l'événement de soumission du formulaire existant par ceci
    taskForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const taskTitle = document.getElementById('taskTitle').value;
        const taskProject = document.getElementById('taskProject');
        const projectId = parseInt(taskProject.value);
        const taskDescription = document.getElementById('taskDescription').value;
        const taskPriority = document.getElementById('taskPriority').value;
        const taskDueDate = document.getElementById('taskDueDate').value;

        if (!taskTitle || !taskPriority || !taskDueDate) {
            alert('Veuillez remplir tous les champs obligatoires');
            return;
        }

        try {
            // Utiliser la fonction createNewTask avec les bonnes données
            const taskData = {
                title: taskTitle,
                project_id: projectId,
                description: taskDescription,
                priority: taskPriority,
                due_date: taskDueDate
            };

            const createdTask = await createNewTask(taskData);
            console.log('Tâche créée avec succès:', createdTask);

            // Fermer la modal et rafraîchir l'affichage
            closeTaskModalFn();
        } catch (error) {
            console.error('Erreur lors de la création de la tâche:', error);
            alert(`Erreur: ${error.message}`);
        }
    });

    // Reste du code d'initialisation...
});
// Données des projets (simulées)
let projects = [
    { id: 1, name: "Application Web", status: "En cours", progress: 75, description: "Développement d'une plateforme de gestion de projet", dueDate: "2025-03-30" },
    { id: 2, name: "Application Mobile", status: "En cours", progress: 40, description: "Développement d'une application mobile de suivi de tâches", dueDate: "2025-04-15" },
    { id: 3, name: "Design UI/UX", status: "À faire", progress: 10, description: "Refonte de l'interface utilisateur pour la plateforme client", dueDate: "2025-04-05" }
];

// Statistiques utilisateur (simulées)
const userStats = {
    activeProjects: 4,
    assignedTasks: 12,
    completedTasks: 8,
    upcomingDeadlines: 2
};

// État de l'application
let currentTaskId = null;
let currentPage = 'dashboard'; // Page active par défaut

// ===== GESTION DE LA NAVIGATION =====

// Définition des pages disponibles
const pages = {
    dashboard: renderDashboardPage,
    projects: renderProjectsPage,
    tasks: renderTasksPage,
    comments: renderCommentsPage,
    team: renderTeamPage,
    settings: renderSettingsPage
};

// Fonction pour changer de page
function changePage(pageName) {
    // Vérifier si la page existe
    if (!pages[pageName]) {
        console.error(`La page ${pageName} n'existe pas`);
        return;
    }

    // Mettre à jour la page actuelle
    currentPage = pageName;

    // Rendre la page
    pages[pageName]();

    // Mettre à jour l'élément actif dans la sidebar
    updateActiveSidebarItem(pageName);
}

// Mettre à jour l'élément actif dans la sidebar
function updateActiveSidebarItem(pageName) {
    // Mapping des identifiants de page aux textes de navigation
    const pageToNavTextMap = {
        'dashboard': 'Tableau de bord',
        'projects': 'Mes Projets',
        'tasks': 'Mes Tâches',
        'comments': 'Commentaires',
        'team': 'Mon Équipe',
        'settings': 'Paramètres'
    };

    // Récupérer le texte correspondant à la page
    const targetNavText = pageToNavTextMap[pageName];

    // Désactiver tous les éléments de navigation
    navItems.forEach(navItem => {
        navItem.classList.remove('active');

        // Si le texte du navItem correspond à la page, l'activer
        const navText = navItem.querySelector('.nav-text').textContent;
        if (navText === targetNavText) {
            navItem.classList.add('active');
        }
    });
}

// ===== FONCTIONS DE RENDU DES PAGES =====

// Fonction pour rendre la page du tableau de bord
function renderDashboardPage() {
    // Structure HTML pour le tableau de bord
    const dashboardHTML = `
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon project-icon">
                        <i class="fas fa-project-diagram"></i>
                    </div>
                    <div class="stat-value">${userStats.activeProjects}</div>
                    <div class="stat-label">Projets actifs</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon task-icon">
                        <i class="fas fa-tasks"></i>
                    </div>
                    <div class="stat-value">${userStats.assignedTasks}</div>
                    <div class="stat-label">Tâches assignées</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon payment-icon">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-value">${userStats.completedTasks}</div>
                    <div class="stat-label">Tâches terminées</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon user-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-value">${userStats.upcomingDeadlines}</div>
                    <div class="stat-label">Échéances proches</div>
                </div>
            </div>

            <!-- My Tasks Section -->
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Mes Tâches en Cours</h2>
                    <button class="btn" id="addTaskBtnInline">
                        <i class="fas fa-plus"></i> Nouvelle Tâche
                    </button>
                </div>
                <div class="filter-section">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" placeholder="Rechercher une tâche...">
                    </div>
                    <select class="filter-select" id="projectFilter">
                        <option value="all">Tous les projets</option>
                        <option value="application-web">Application Web</option>
                        <option value="application-mobile">Application Mobile</option>
                        <option value="design-ui-ux">Design UI/UX</option>
                    </select>
                    <select class="filter-select" id="statusFilter">
                        <option value="all">Tous les statuts</option>
                        <option value="todo">À faire</option>
                        <option value="in-progress">En cours</option>
                        <option value="review">En revue</option>
                        <option value="done">Terminé</option>
                    </select>
                </div>
                <div class="logs-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Tâche</th>
                                <th>Projet</th>
                                <th>Priorité</th>
                                <th>Statut</th>
                                <th>Échéance</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tasksTableBody">
                            <!-- Les tâches seront générées par JavaScript -->
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <div class="page-item disabled">
                        <i class="fas fa-chevron-left"></i>
                    </div>
                    <div class="page-item active">1</div>
                    <div class="page-item">2</div>
                    <div class="page-item">3</div>
                    <div class="page-item">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>

            <!-- Recent Projects Section -->
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Mes Projets Récents</h2>
                    <button class="btn btn-secondary" id="viewAllProjects">
                        <i class="fas fa-eye"></i> Voir tous
                    </button>
                </div>
                <div class="projects-grid" id="projectsGrid">
                    <!-- Les projets seront générés par JavaScript -->
                </div>
            </div>
        `;

    // Mettre à jour le contenu principal sans l'en-tête
    updateMainContentWithoutHeader(dashboardHTML);

    // Rendre les tâches et les projets
    renderTasks();
    renderProjects(projects.slice(0, 2)); // Limiter à 2 projets sur le tableau de bord

    // Attacher les événements
    document.getElementById('addTaskBtnInline').addEventListener('click', () => openTaskModal());
    document.getElementById('viewAllProjects').addEventListener('click', () => changePage('projects'));

    // Réattacher les événements de recherche et de filtrage
    const searchInputNew = document.querySelector('.search-box input');
    const filterSelectsNew = document.querySelectorAll('.filter-select');

    if (searchInputNew) {
        searchInputNew.addEventListener('input', filterTasks);
    }

    filterSelectsNew.forEach(select => {
        select.addEventListener('change', filterTasks);
    });
}

// Fonction pour rendre la page des projets
function renderProjectsPage() {
    const projectsHTML = `
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Tous Mes Projets</h2>
                    <button class="btn">
                        <i class="fas fa-plus"></i> Nouveau Projet
                    </button>
                </div>
                <div class="filter-section">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" placeholder="Rechercher un projet...">
                    </div>
                    <select class="filter-select">
                        <option value="all">Tous les statuts</option>
                        <option value="in-progress">En cours</option>
                        <option value="completed">Terminé</option>
                        <option value="pending">En attente</option>
                    </select>
                </div>
                <div class="projects-grid" id="projectsGrid">
                    <!-- Les projets seront générés par JavaScript -->
                </div>
            </div>
        `;

    updateMainContentWithoutHeader(projectsHTML);
    renderProjects(projects); // Afficher tous les projets
}

// Fonction pour rendre la page des tâches
function renderTasksPage() {
    const tasksHTML = `
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Toutes Mes Tâches</h2>
                    <button class="btn" id="addTaskBtnInline">
                        <i class="fas fa-plus"></i> Nouvelle Tâche
                    </button>
                </div>
                <div class="filter-section">
                    <div class="search-box">
                        <i class="fas fa-search"></i>
                        <input type="text" placeholder="Rechercher une tâche...">
                    </div>
                    <select class="filter-select" id="projectFilter">
                        <option value="all">Tous les projets</option>
                        <option value="application-web">Application Web</option>
                        <option value="application-mobile">Application Mobile</option>
                        <option value="design-ui-ux">Design UI/UX</option>
                    </select>
                    <select class="filter-select" id="statusFilter">
                        <option value="all">Tous les statuts</option>
                        <option value="todo">À faire</option>
                        <option value="in-progress">En cours</option>
                        <option value="review">En revue</option>
                        <option value="done">Terminé</option>
                    </select>
                </div>
                <div class="logs-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Tâche</th>
                                <th>Projet</th>
                                <th>Priorité</th>
                                <th>Statut</th>
                                <th>Échéance</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="tasksTableBody">
                            <!-- Les tâches seront générées par JavaScript -->
                        </tbody>
                    </table>
                </div>
                <div class="pagination">
                    <div class="page-item disabled">
                        <i class="fas fa-chevron-left"></i>
                    </div>
                    <div class="page-item active">1</div>
                    <div class="page-item">2</div>
                    <div class="page-item">3</div>
                    <div class="page-item">
                        <i class="fas fa-chevron-right"></i>
                    </div>
                </div>
            </div>
        `;

    updateMainContentWithoutHeader(tasksHTML);
    renderTasks();

    // Attacher les événements
    document.getElementById('addTaskBtnInline').addEventListener('click', () => openTaskModal());

    // Réattacher les événements de recherche et de filtrage
    const searchInputNew = document.querySelector('.search-box input');
    const filterSelectsNew = document.querySelectorAll('.filter-select');

    if (searchInputNew) {
        searchInputNew.addEventListener('input', filterTasks);
    }

    filterSelectsNew.forEach(select => {
        select.addEventListener('change', filterTasks);
    });
}

// Pages supplémentaires (à implémenter selon les besoins)
function renderCommentsPage() {
    updateMainContentWithoutHeader(`
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Commentaires</h2>
                </div>
                <div class="placeholder-content">
                    <i class="fas fa-comment-alt placeholder-icon"></i>
                    <p>Cette fonctionnalité sera bientôt disponible.</p>
                </div>
            </div>
        `);
}

function renderTeamPage() {
    updateMainContentWithoutHeader(`
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Mon Équipe</h2>
                </div>
                <div class="placeholder-content">
                    <i class="fas fa-user-friends placeholder-icon"></i>
                    <p>Cette fonctionnalité sera bientôt disponible.</p>
                </div>
            </div>
        `);
}

function renderSettingsPage() {
    updateMainContentWithoutHeader(`
            <div class="section">
                <div class="section-header">
                    <h2 class="section-title">Paramètres</h2>
                </div>
                <div class="placeholder-content">
                    <i class="fas fa-cog placeholder-icon"></i>
                    <p>Cette fonctionnalité sera bientôt disponible.</p>
                </div>
            </div>
        `);
}

// Fonction pour mettre à jour le contenu principal sans toucher à l'en-tête
function updateMainContentWithoutHeader(htmlContent) {
    // Obtenir l'en-tête actuel
    const header = mainContent.querySelector('.header');

    // Vider le contenu principal
    mainContent.innerHTML = '';

    // Réinsérer l'en-tête
    mainContent.appendChild(header);

    // Ajouter le nouveau contenu
    mainContent.insertAdjacentHTML('beforeend', htmlContent);
}

// ===== GESTION DES TÂCHES =====

// Fonction pour rendre les tâches dans le tableau
function renderTasks(taskList) {
    const tbody = document.getElementById('tasksTableBody');
    if (!tbody) return; // Protection contre les erreurs

    tbody.innerHTML = '';

    if (taskList.length === 0) {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td colspan="6" class="text-center">Aucune tâche trouvée</td>';
        tbody.appendChild(tr);
        return;
    }

    taskList.forEach(task => {
        const tr = document.createElement('tr');

        // Déterminer les classes CSS selon la priorité et le statut
        let priorityClass = task.priority === "Haute" ? 'status-danger' :
            task.priority === "Moyenne" ? 'status-warning' : 'status-info';

        let statusClass = task.status === "À faire" ? 'status-info' :
            task.status === "En cours" ? 'status-warning' :
                task.status === "En revue" ? 'status-primary' : 'status-success';

        // Formatter la date pour l'affichage (YYYY-MM-DD -> DD/MM/YYYY)
        const dateParts = task.dueDate.split('-');
        const formattedDate = `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}`;

        tr.innerHTML = `
                <td>${task.title}</td>
                <td>${task.project}</td>
                <td>
                    <span class="td-status">
                        <span class="status-indicator ${priorityClass}"></span>
                        <span class="status-label">${task.priority}</span>
                    </span>
                </td>
                <td>
                    <span class="td-status">
                        <span class="status-indicator ${statusClass}"></span>
                        <span class="status-label">${task.status}</span>
                    </span>
                </td>
                <td>${formattedDate}</td>
                <td class="action-cell">
                    <button class="action-btn view-btn" data-task-id="${task.id}">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="action-btn edit-btn" data-task-id="${task.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete-btn" data-task-id="${task.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            `;

        tbody.appendChild(tr);
    });

    attachTaskEventListeners();
}

// Fonction pour rendre les projets
function renderProjects(projectList) {
    const projectsGrid = document.getElementById('projectsGrid');
    if (!projectsGrid) return; // Protection contre les erreurs

    projectsGrid.innerHTML = '';

    if (projectList.length === 0) {
        projectsGrid.innerHTML = '<div class="empty-state">Aucun projet trouvé</div>';
        return;
    }

    projectList.forEach(project => {
        // Formatter la date pour l'affichage (YYYY-MM-DD -> DD/MM/YYYY)
        const dateParts = project.dueDate.split('-');
        const formattedDate = `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}`;

        const projectCard = document.createElement('div');
        projectCard.className = 'project-card';
        projectCard.innerHTML = `
                <div class="project-header">
                    <h3>${project.name}</h3>
                    <span class="project-status">${project.status}</span>
                </div>
                <div class="project-info">
                    <p>${project.description}</p>
                    <div class="project-meta">
                        <div class="project-progress">
                            <span class="progress-label">Progression: ${project.progress}%</span>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${project.progress}%;"></div>
                            </div>
                        </div>
                        <div class="project-date">
                            <i class="fas fa-calendar"></i>
                            <span>Échéance: ${formattedDate}</span>
                        </div>
                    </div>
                </div>
            `;

        projectsGrid.appendChild(projectCard);
    });
}

// Fonction pour filtrer les tâches
function filterTasks() {
    const searchTerm = document.querySelector('.search-box input').value.toLowerCase();
    const projectFilter = document.getElementById('projectFilter')?.value || 'all';
    const statusFilter = document.getElementById('statusFilter')?.value || 'all';

    let filteredTasks = tasks;

    // Filtre par terme de recherche
    if (searchTerm) {
        filteredTasks = filteredTasks.filter(task =>
            task.title.toLowerCase().includes(searchTerm) ||
            task.project.toLowerCase().includes(searchTerm)
        );
    }

    // Filtre par projet
    if (projectFilter !== 'all') {
        const formattedProjectFilter = projectFilter.replace(/-/g, ' ');
        filteredTasks = filteredTasks.filter(task =>
            task.project.toLowerCase() === formattedProjectFilter
        );
    }

    // Filtre par statut
    if (statusFilter !== 'all') {
        const statusMap = {
            "todo": "À faire",
            "in-progress": "En cours",
            "review": "En revue",
            "done": "Terminé"
        };
        filteredTasks = filteredTasks.filter(task => task.status === statusMap[statusFilter]);
    }

    renderTasks(filteredTasks);
}

// Attacher les événements aux boutons des tâches
function attachTaskEventListeners() {
    document.querySelectorAll('.view-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const taskId = parseInt(btn.getAttribute('data-task-id'));
            viewTaskDetails(taskId);
        });
    });

    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const taskId = parseInt(btn.getAttribute('data-task-id'));
            openTaskModal(taskId);
        });
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const taskId = parseInt(btn.getAttribute('data-task-id'));
            if (confirm('Êtes-vous sûr de vouloir supprimer cette tâche ?')) {
                deleteTask(taskId);
            }
        });
    });
}

// Fonction pour afficher les détails d'une tâche
function viewTaskDetails(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (task) {
        // Créer une modal plus élégante pour afficher les détails
        const detailsModalHTML = `
                <div class="modal-overlay task-details-modal active">
                    <div class="modal">
                        <div class="modal-header">
                            <h2 class="modal-title">Détails de la tâche</h2>
                            <button class="close-modal" id="closeDetailsModal">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="modal-content">
                            <div class="task-detail">
                                <span class="detail-label">Titre:</span>
                                <span class="detail-value">${task.title}</span>
                            </div>
                            <div class="task-detail">
                                <span class="detail-label">Projet:</span>
                                <span class="detail-value">${task.project}</span>
                            </div>
                            <div class="task-detail">
                                <span class="detail-label">Description:</span>
                                <span class="detail-value">${task.description || 'Aucune description'}</span>
                            </div>
                            <div class="task-detail">
                                <span class="detail-label">Priorité:</span>
                                <span class="detail-value">${task.priority}</span>
                            </div>
                            <div class="task-detail">
                                <span class="detail-label">Statut:</span>
                                <span class="detail-value">${task.status}</span>
                            </div>
                            <div class="task-detail">
                                <span class="detail-label">Échéance:</span>
                                <span class="detail-value">${task.dueDate}</span>
                            </div>
                        </div>
                        <div class="modal-actions">
                            <button class="btn btn-secondary" id="closeDetailsBtn">Fermer</button>
                            <button class="btn" id="editFromDetailsBtn" data-task-id="${task.id}">Modifier</button>
                        </div>
                    </div>
                </div>
            `;

        // Ajouter la modal au body
        document.body.insertAdjacentHTML('beforeend', detailsModalHTML);

        // Ajouter les écouteurs d'événements
        document.getElementById('closeDetailsModal').addEventListener('click', closeDetailsModal);
        document.getElementById('closeDetailsBtn').addEventListener('click', closeDetailsModal);
        document.getElementById('editFromDetailsBtn').addEventListener('click', function () {
            closeDetailsModal();
            openTaskModal(taskId);
        });

        // Empêcher le défilement du body
        document.body.classList.add('modal-open');
    }
}

// Fonction pour fermer la modal de détails
function closeDetailsModal() {
    const detailsModal = document.querySelector('.task-details-modal');
    if (detailsModal) {
        detailsModal.remove();
        document.body.classList.remove('modal-open');
    }
}

// Fonction pour supprimer une tâche
function deleteTask(taskId) {
    tasks = tasks.filter(t => t.id !== taskId);
    filterTasks();
}

// ===== GESTION DE LA MODAL DE TÂCHE =====

// Remplacer la gestion d'événement existante pour le bouton addTaskBtn
addTaskBtn.addEventListener('click', () => openTaskModal());

// Assurez-vous que openTaskModal est correctement définie
function openTaskModal(taskId = null) {
    taskModal.classList.add('active');
    document.body.classList.add('modal-open');

    // Réinitialiser le formulaire
    taskForm.reset();
    currentTaskId = taskId;

    if (taskId) {
        const task = tasks.find(t => t.id === taskId);
        if (task) {
            document.getElementById('taskTitle').value = task.title;
            document.getElementById('taskProject').value = task.project.toLowerCase().replace(/\s+/g, '-');
            document.getElementById('taskDescription').value = task.description || '';
            document.getElementById('taskPriority').value = task.priority.toLowerCase();
            document.getElementById('taskDueDate').value = task.dueDate;

            // Mettre à jour le titre de la modal
            const modalTitle = document.querySelector('#taskModal .modal-title');
            if (modalTitle) {
                modalTitle.textContent = 'Modifier la tâche';
            }
        }
    } else {
        // Réinitialiser le titre pour une nouvelle tâche
        const modalTitle = document.querySelector('#taskModal .modal-title');
        if (modalTitle) {
            modalTitle.textContent = 'Ajouter une tâche';
        }
    }
}

// Utilisez une seule version de la fonction pour fermer la modal
function closeTaskModalFn() {
    taskModal.classList.remove('active');
    document.body.classList.remove('modal-open');
    currentTaskId = null;
}

// Assurez-vous que tous les gestionnaires d'événements utilisent la même fonction
closeTaskModal.addEventListener('click', closeTaskModalFn);
cancelTaskBtn.addEventListener('click', closeTaskModalFn);

// ===== ÉVÉNEMENTS =====

// Gestion de la sidebar
toggleSidebarBtn.addEventListener('click', function () {
    sidebar.classList.toggle('active');
    mobileOverlay.classList.toggle('active');
});

mobileOverlay.addEventListener('click', function () {
    sidebar.classList.remove('active');
    mobileOverlay.classList.remove('active');
});

// Gestion de la navigation
navItems.forEach(navItem => {
    navItem.addEventListener('click', function (e) {
        e.preventDefault();

        // Enlever la classe active de tous les éléments de navigation
        navItems.forEach(item => item.classList.remove('active'));

        // Ajouter la classe active à l'élément cliqué
        navItem.classList.add('active');

        // Déterminer la page active à partir du texte
        const navText = navItem.querySelector('.nav-text').textContent;

        // Mapping des textes de navigation aux identifiants de page
        const pageMapping = {
            'Tableau de bord': 'dashboard',
            'Mes Projets': 'projects',
            'Mes Tâches': 'tasks',
            'Commentaires': 'comments',
            'Mon Équipe': 'team',
            'Paramètres': 'settings'
        };

        // Changer la page
        if (pageMapping[navText]) {
            changePage(pageMapping[navText]);

            // Fermer la sidebar sur mobile après navigation
            if (window.innerWidth < 768) {
                sidebar.classList.remove('active');
                mobileOverlay.classList.remove('active');
            }
        }
    });
});

// Gestion de la modal de tâche
addTaskBtn.addEventListener('click', () => openTaskModal());
closeTaskModal.addEventListener('click', closeTaskModalFn);
cancelTaskBtn.addEventListener('click', closeTaskModalFn);

// Gestion du formulaire de tâche
taskForm.addEventListener('submit', function (e) {
    e.preventDefault();

    const taskTitle = document.getElementById('taskTitle').value;
    const taskProject = document.getElementById('taskProject');
    const taskProjectText = taskProject.options[taskProject.selectedIndex].text;
    const taskDescription = document.getElementById('taskDescription').value;
    const taskPriority = document.getElementById('taskPriority');
    const taskPriorityText = taskPriority.options[taskPriority.selectedIndex].text;
    const taskDueDate = document.getElementById('taskDueDate').value;

    if (!taskTitle || !taskDueDate) {
        alert('Veuillez remplir tous les champs obligatoires');
        return;
    }

    if (currentTaskId) {
        // Mettre à jour une tâche existante
        const taskIndex = tasks.findIndex(t => t.id === currentTaskId);
        if (taskIndex !== -1) {
            tasks[taskIndex] = {
                ...tasks[taskIndex],
                title: taskTitle,
                project: taskProjectText,
                description: taskDescription,
                priority: taskPriorityText,
                dueDate: taskDueDate
            };
        }
    } else {
        // Créer une nouvelle tâche
        const newTaskId = tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1;
        tasks.push({
            id: newTaskId,
            title: taskTitle,
            project: taskProjectText,
            description: taskDescription,
            priority: taskPriorityText,
            status: 'À faire',
            dueDate: taskDueDate
        });
    }

    // Fermer la modal et rafraîchir l'affichage
    closeTaskModalFn();
    filterTasks();
});

// Gestion de la recherche et des filtres
if (searchInput) {
    searchInput.addEventListener('input', filterTasks);
}

if (filterSelects) {
    filterSelects.forEach(select => {
        select.addEventListener('change', filterTasks);
    });
}

// Pagination
paginationItems.forEach(pageItem => {
    pageItem.addEventListener('click', function () {
        if (!pageItem.classList.contains('disabled')) {
            paginationItems.forEach(item => item.classList.remove('active'));
            pageItem.classList.add('active');
        }
    });
    renderDashboardPage();

});

// Initialisation de la page par défaut
