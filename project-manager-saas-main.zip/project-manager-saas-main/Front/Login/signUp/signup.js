document.addEventListener("DOMContentLoaded", function () {
  const dropdown = document.querySelector(".custom-dropdown")
  const dropdownSelected = dropdown.querySelector(".dropdown-selected")
  const dropdownOptions = dropdown.querySelector(".dropdown-options")
  const options = dropdown.querySelectorAll(".dropdown-option")
  const hiddenSelect = dropdown.querySelector(".hidden-select")
  const form = document.querySelector("form")
  let projectKeyField = null

  // Toggle dropdown
  dropdownSelected.addEventListener("click", function () {
    dropdownSelected.classList.toggle("active")
    dropdownOptions.classList.toggle("show")
  })

  // Select option
  options.forEach((option) => {
    option.addEventListener("click", function () {
      const value = this.getAttribute("data-value")
      const text = this.textContent

      // Update the displayed text
      dropdownSelected.innerHTML = text
      dropdownSelected.classList.remove("dropdown-placeholder")

      // Update the hidden select value
      hiddenSelect.value = value
      console.log("Valeur sélectionnée :", hiddenSelect.value)

      // Trigger change event for form validation
      const event = new Event("change", { bubbles: true })
      hiddenSelect.dispatchEvent(event)

      // Close dropdown
      dropdownSelected.classList.remove("active")
      dropdownOptions.classList.remove("show")
    })
  })

  // Close dropdown when clicking outside
  document.addEventListener("click", function (event) {
    if (!dropdown.contains(event.target)) {
      dropdownSelected.classList.remove("active")
      dropdownOptions.classList.remove("show")
    }
  })

  // Add project key field if 'Contributeur' is selected
  hiddenSelect.addEventListener("change", function () {
    if (hiddenSelect.value === "contributeur") {
      if (!projectKeyField) {
        projectKeyField = document.createElement("div")
        projectKeyField.classList.add("form-group")
        projectKeyField.innerHTML = `
                    <label for="projectKey">Clé de projet</label>
                    <input type="text" id="projectKey" placeholder="Entrez la clé du projet" required>
                `
        form.insertBefore(projectKeyField, form.querySelector(".btn"))
      }
    } else {
      if (projectKeyField) {
        projectKeyField.remove()
        projectKeyField = null
      }
    }
  })
  //Fetch pour créer un user
  let API_URL = "http://localhost:3000/api/"

  form.addEventListener("submit", function (event) {
    event.preventDefault()
    console.log("Form submitted")
    const name = document.getElementById("nom").value
    const email = document.getElementById("email").value
    const password = document.getElementById("password").value
    const role = document.getElementById("role").value
    const projectKey = document.getElementById("projectKey")
      ? document.getElementById("projectKey").value
      : null
    console.log(name, email, password, role)
    fetch(`${API_URL}users`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ name, email, password, role }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(data)
        if (projectKey) {
          console.log(projectKey)
          const owner_id = projectKey.replace(/\D/g, "")
          console.log(owner_id)
          {
            fetch(`${API_URL}project-members`, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                user_id: owner_id,
                related_user_id: data.id,
              }),
            })
              .then((response) => response.json())
              .then((data) => {
                console.log(data)
              })
              .catch((error) => {
                console.error("Error:", error)
              })
          }
        }
        window.location.href = "../SignIn/signin.html"
      })

      .catch((error) => {
        console.error("Error:", error)
      })
  })
})
