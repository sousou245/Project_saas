document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.getElementById("loginForm")
  if (!loginForm) return console.error("Formulaire introuvable")

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    const email = document.getElementById("email").value
    const password = document.getElementById("password").value

    try {
      const response = await fetch("http://localhost:3000/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      })

      if (!response.ok) {
        const { message } = await response.json()
        throw new Error(message || "Erreur lors de la connexion")
      }

      const data = await response.json()
      console.log("Connexion réussie", data)

      // Supprimer l'ancien token si il existe
      localStorage.removeItem("token")

      // Stocker le nouveau token dans le localStorage
      localStorage.setItem("token", data.token)

      // Récupérer le rôle de l'utilisateur depuis la réponse
      const userRole = data.user.role // Assurez-vous que la réponse contient bien "user" avec la propriété "role"

      // Rediriger en fonction du rôle de l'utilisateur
      if (userRole === "admin") {
        window.location.href = "../../admin/admin.html"
      } else if (userRole === "contributeur") {
        window.location.href = "../../contributor/contributor.html"
      } else if (userRole === "chef") {
        window.location.href = "../../project-master/chef.html"
      } else {
        // Si le rôle n'est pas reconnu, rediriger vers une page générique
        window.location.href = "dashboard.html"
      }
    } catch (error) {
      console.error("Erreur :", error.message)
      alert("Erreur lors de la connexion : " + error.message)
    }
  })
  console.log(localStorage.getItem("token"))
})
