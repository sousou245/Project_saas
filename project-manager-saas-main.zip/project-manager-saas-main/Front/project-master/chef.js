document.addEventListener("DOMContentLoaded", () => {
  // Sidebar Toggle Functionality
  let user
  const API_URL = "http://localhost:3000/api"
  const sidebar = document.getElementById("sidebar")
  const mobileOverlay = document.getElementById("mobile-overlay")
  const toggleSidebarBtn = document.getElementById("toggle-sidebar")

  toggleSidebarBtn.addEventListener("click", () => {
    sidebar.classList.toggle("open")
    mobileOverlay.classList.toggle("active")
  })

  mobileOverlay.addEventListener("click", () => {
    sidebar.classList.remove("open")
    mobileOverlay.classList.remove("active")
  })

  const token = localStorage.getItem("token")
  console.log(token)
  if (!token) {
    // Si le token n'est pas présent, redirige l'utilisateur vers la page de connexion
    window.location.href = "../Login/SignIn/signin.html"
    return
  }
  console.log(`${API_URL}/me`)
  // Faire une requête à l'API pour récupérer les informations de l'utilisateur
  fetch(`${API_URL}/me`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`, // Utilisation du token dans l'en-tête
    },
  })
    .then((response) => response.json())
    .then((data) => {
      // mettre data dans une variable
      user = data
      console.log("Utilisateur connecté :", user)
      // l'id
      console.log("ID de l'utilisateur :", user.id)
      loadProjects()
      loadTeamNumber(user.id)
      const userkey = document.getElementById("user-key")

      userkey.innerHTML = generatekey(user.id)
      console.log(userkey)
    })
    .catch((error) => {
      console.error("Erreur :", error)
      alert("Erreur lors de la récupération des informations utilisateur")
    })

  // New Project Modal Functionality
  const addProjectBtn = document.getElementById("add-project-btn")
  const projectModalOverlay = document.getElementById("project-modal-overlay")
  const closeProjectModalBtn = document.getElementById("close-project-modal")
  const cancelProjectBtn = document.getElementById("cancel-project")
  const projectForm = document.getElementById("project-form")

  // Open Modal
  addProjectBtn.addEventListener("click", async () => {
    projectModalOverlay.classList.add("active")
    const membresSelecteur = document.getElementById("project-members")

    // Message de chargement
    membresSelecteur.innerHTML = `<option disabled selected>Chargement des membres...</option>`

    try {
      // Récupération owner_id
      const meResponse = await fetch(`${API_URL}/me`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!meResponse.ok) throw new Error("Erreur de récupération utilisateur")

      const { id: ownerId } = await meResponse.json()

      // Récupération des membres
      const response = await fetch(`${API_URL}/projects/${ownerId}/members`)

      if (!response.ok) throw new Error("Erreur de récupération des membres")

      const membres = await response.json()

      // Vérification des données reçues
      console.log("Membres reçus:", membres)

      // Construction des options
      let optionsHTML = ""
      if (membres.length > 0) {
        optionsHTML = membres
          .map((m) => {
            console.log(m)
            // Accès direct aux propriétés de l'objet membre
            const fullName = m.member_name || "Nom inconnu" // 'member_name' est une propriété directe
            return `<option value="${m.user_id}">${fullName}</option>` // 'id' est aussi une propriété directe
          })
          .join("")
      } else {
        optionsHTML = `<option disabled>Aucun membre disponible</option>`
      }

      // Mise à jour du select
      membresSelecteur.innerHTML = `
            <option value="" disabled selected>Sélectionnez un membre</option>
            ${optionsHTML}
        `
    } catch (error) {
      console.error("Erreur:", error)
      membresSelecteur.innerHTML = `
            <option disabled>Erreur de chargement</option>
            <option disabled>${error.message}</option>
        `
    } finally {
      // Retirer l'attribut disabled sur le premier élément
      const firstOption = membresSelecteur.querySelector("option")
      if (firstOption) firstOption.disabled = false
    }
  })

  // Close Modal Functions
  const closeProjectModal = () => {
    projectModalOverlay.classList.remove("active")
    projectForm.reset()
  }

  closeProjectModalBtn.addEventListener("click", closeProjectModal)
  cancelProjectBtn.addEventListener("click", closeProjectModal)

  // Project Form Submission
  projectForm.addEventListener("submit", async (e) => {
    e.preventDefault()

    // Récupération des valeurs des champs
    const projectName = document.getElementById("project-name").value
    const projectDescription = document.getElementById(
      "project-description"
    ).value
    const projectDeadline = document.getElementById("project-deadline").value
    const projectMembers = Array.from(
      document.getElementById("project-members").selectedOptions
    ).map((option) => option.value) // Liste des membres sélectionnés
    console.log(projectMembers)
    // Vérification que le nom du projet et l'ID du propriétaire (user.id) sont présents
    if (!projectName || !user.id) {
      alert("Nom du projet et propriétaire requis !")
      return
    }

    try {
      // Requête de création du projet via l'API
      const response = await fetch(`${API_URL}/projects`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: projectName,
          description: projectDescription,
          limite_date: projectDeadline,
          owner_id: user.id,
          members: projectMembers, // Ajout des membres sélectionnés ici
        }),
      })

      // Vérification du succès de la requête
      if (response.ok) {
        const newProject = await response.json()
        closeProjectModal() // Fermeture du modal après création
        loadProjects() // Rafraîchir la liste des projets
      } else {
        const errorData = await response.json()
        alert(`Erreur: ${errorData.message}`)
      }
    } catch (error) {
      console.error("Erreur lors de la création du projet:", error)
      alert("Une erreur est survenue lors de la création du projet.")
    }
  })

  // Project Filtering
  const projectSearch = document.getElementById("project-search")
  const projectFilter = document.getElementById("project-filter")
  const projectsList = document.getElementById("projects-list")

  const generatekey = (owner_id) => {
    //création d'une clée pour le chef contenant l'id et des lettres aléatoires en maj
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const key =
      owner_id +
      letters[Math.floor(Math.random() * letters.length)] +
      letters[Math.floor(Math.random() * letters.length)] +
      letters[Math.floor(Math.random() * letters.length)]
    return key
  }

  const loadProjects = async () => {
    try {
      if (!API_URL || !user || !user.id) {
        throw new Error("Configuration manquante")
      }

      const response = await fetch(`${API_URL}/projects/${user.id}`)
      if (!response.ok)
        throw new Error(`Erreur HTTP! statut: ${response.status}`)

      const projects = await response.json()
      const projectCountElement = document.getElementById("projects-count")
      if (projectCountElement) projectCountElement.textContent = projects.length

      if (projectsList) {
        const projectsHtml = await Promise.all(
          projects.map(async (project) => {
            let members = []
            try {
              members = JSON.parse(project.members)
            } catch (e) {
              console.error("Erreur de parsing des membres:", e)
            }

            const validMembers = members
              .filter((m) => m !== "" && !isNaN(m))
              .map(Number)

            const membersData = await Promise.all(
              validMembers.map(async (memberId) => {
                try {
                  const userResponse = await fetch(
                    `${API_URL}/users/${memberId}`
                  )
                  if (!userResponse.ok)
                    throw new Error("Utilisateur non trouvé")
                  const user = await userResponse.json()
                  return {
                    id: memberId,
                    initial: user.name ? user.name[0].toUpperCase() : "?",
                    name: user.name || `Membre ${memberId}`,
                  }
                } catch (error) {
                  console.error(`Erreur avec l'utilisateur ${memberId}:`, error)
                  return {
                    id: memberId,
                    initial: "?",
                    name: `Membre ${memberId}`,
                  }
                }
              })
            )

            return `
                    <tr>
                        <td>${project.name}</td>
                        <td>
                            <div class="members-container">
                                ${
                                  membersData.length > 0
                                    ? `
                                        ${membersData
                                          .slice(0, 3)
                                          .map(
                                            (member) => `
                                                <span class="member-badge" title="${member.name}">
                                                    ${member.initial}
                                                </span>
                                            `
                                          )
                                          .join("")}
                                        ${
                                          membersData.length > 3
                                            ? `
                                            <span class="member-badge member-badge-more">
                                                +${membersData.length - 3}
                                            </span>`
                                            : ""
                                        }
                                    `
                                    : "Aucun membre"
                                }
                            </div>
                        </td>
                        <td>
                            <span class="date-badge ${getDateBadgeClass(
                              project.limite_date
                            )}">
                                ${new Date(
                                  project.limite_date
                                ).toLocaleDateString()}
                            </span>
                        </td>
                        <td>
                            <span class="status-label ${getStatusClass(
                              project.status
                            )}">
                                <p>${project.status || "En Cours"}</p>
                            </span>
                        </td>
                        <td>
                            <div class="progress-container">
                                <div 
                                    class="progress-bar" 
                                    style="width: ${project.progress || 75}%"
                                    title="${project.progress || 0}% completed">
                                </div>
                            </div>
                        </td>
                        <td class="action-cell">
                            <button class="action-btn view-btn" data-id="${
                              project.id
                            }">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn edit-btn" data-id="${
                              project.id
                            }">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete-btn" data-id="${
                              project.id
                            }">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `
          })
        )

        projectsList.innerHTML = projectsHtml.join("")
      }

      function getDateBadgeClass(date) {
        const today = new Date()
        const projectDate = new Date(date)
        const diffDays = (projectDate - today) / (1000 * 60 * 60 * 24)

        if (diffDays < 0) return "date-overdue"
        if (diffDays <= 7) return "date-close"
        return "date-upcoming"
      }

      function getStatusClass(status) {
        const statusMap = {
          Active: "status-active",
          Completed: "status-completed",
          Delayed: "status-delayed",
          Pending: "status-pending",
        }
        return statusMap[status] || "status-default"
      }

      document.querySelectorAll(".view-btn").forEach((btn) => {
        btn.addEventListener("click", () => viewProject(btn.dataset.id))
      })

      document.querySelectorAll(".edit-btn").forEach((btn) => {
        btn.addEventListener("click", () => editProject(btn.dataset.id))
      })

      document.querySelectorAll(".delete-btn").forEach((btn) => {
        btn.addEventListener("click", () => deleteProject(btn.dataset.id))
      })
    } catch (error) {
      console.error("Error loading projects:", error)
      if (projectsList) {
        projectsList.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center text-danger">
                        Erreur de chargement: ${
                          error.message || "Veuillez réessayer"
                        }
                    </td>
                </tr>
            `
      }
    }
  } // Filter and Search Projects
  const filterProjects = () => {
    const searchTerm = projectSearch.value.toLowerCase()
    const filterStatus = projectFilter.value

    const rows = projectsList.querySelectorAll("tr")
    rows.forEach((row) => {
      const projectName = row.cells[0].textContent.toLowerCase()
      const projectStatus = row.cells[3]
        .querySelector(".status")
        .textContent.toLowerCase()

      const matchesSearch = projectName.includes(searchTerm)
      const matchesFilter =
        filterStatus === "all" || projectStatus === filterStatus

      row.style.display = matchesSearch && matchesFilter ? "" : "none"
    })
  }

  projectSearch.addEventListener("input", filterProjects)
  projectFilter.addEventListener("change", filterProjects)

  // Edit Project Function
  const editProject = async (projectId) => {
    try {
      const response = await fetch(`/api/projects/${projectId}`)
      const project = await response.json()

      // Populate modal with project details
      document.getElementById("project-name").value = project.name
      document.getElementById("project-description").value = project.description
      document.getElementById("project-deadline").value = project.deadline

      // Select members
      const memberSelect = document.getElementById("project-members")
      Array.from(memberSelect.options).forEach((option) => {
        option.selected = project.members.some((m) => m.id == option.value)
      })

      // Change modal to edit mode
      projectModalOverlay.classList.add("active")
      projectForm.dataset.editMode = "true"
      projectForm.dataset.projectId = projectId
    } catch (error) {
      console.error("Erreur de chargement du projet:", error)
      alert("Impossible de charger les détails du projet.")
    }
  }

  // Delete Project Function
  const deleteProject = async (projectId) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce projet ?")) return

    try {
      const response = await fetch(`/api/projects/${projectId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        loadProjects() // Refresh project list
      } else {
        const errorData = await response.json()
        alert(`Erreur: ${errorData.message}`)
      }
    } catch (error) {
      console.error("Erreur de suppression du projet:", error)
      alert("Une erreur est survenue lors de la suppression du projet.")
    }
  }

  const loadTeamNumber = async (userId) => {
    try {
      const response = await fetch(`${API_URL}/projects/${userId}/members`)

      // Gestion des erreurs HTTP
      if (!response.ok) {
        throw new Error(
          `Erreur HTTP ${response.status}: ${await response.text()}`
        )
      }

      const data = await response.json()

      // Vérification du format des données
      if (!Array.isArray(data)) {
        throw new Error("Format de données invalide")
      }

      // Mise à jour de l'UI avec vérification de l'élément DOM
      const teamNumberElement = document.getElementById("team-members")
      if (teamNumberElement) {
        teamNumberElement.textContent = data.length
      }
    } catch (error) {
      console.error("Erreur de chargement de l'équipe:", error)
    }
  }
})
