// app.js ou index.js principal
const express = require("express")
const cors = require("cors")
const bodyParser = require("body-parser")
const app = express()
const PORT = process.env.PORT || 3000

// Middleware pour parser le JSON
app.use(bodyParser.json())
app.use(cors())

// Importer toutes les routes
const projectRoutes = require("./routes/ProjectRoutes")
const taskRoutes = require("./routes/TaskRoutes")
const userRoutes = require("./routes/UserRoutes")
const projectMemberRoutes = require("./routes/ProjectMemberRoute")
const taskCommentRoutes = require("./routes/TaskCommentsRoutes")
const logRoutes = require("./routes/LogRoutes")

// Configurer les routes
app.use("/api", projectRoutes)
app.use("/api", taskRoutes)
app.use("/api", userRoutes)
app.use("/api", projectMemberRoutes)
app.use("/api", taskCommentRoutes)
app.use("/api", logRoutes)

// Gestion des routes non trouvées
app.use((req, res) => {
  res.status(404).json({ message: "Endpoint non trouvé" })
})

// Gestion des erreurs globale
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).json({ message: "Erreur interne du serveur" })
})

// Démarrer le serveur
app.listen(PORT, () => {
  console.log(`Serveur démarré sur http://localhost:${PORT}`)
})
