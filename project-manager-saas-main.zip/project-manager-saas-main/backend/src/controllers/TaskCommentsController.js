const TaskComment = require("../models/TaskComments")

const addComment = async (req, res) => {
  try {
    const { task_id, user_id, content } = req.body

    if (!task_id || !user_id || !content) {
      return res.status(400).json({ message: "Champs requis manquants" })
    }

    const comment = await TaskComment.create({
      task_id,
      user_id,
      content,
      created_at: new Date(),
    })

    res.status(201).json(comment)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur d'ajout de commentaire" })
  }
}

const getTaskComments = async (req, res) => {
  try {
    const { task_id } = req.params
    const comments = await TaskComment.findAll({
      where: { task_id },
      include: [User],
    })
    res.status(200).json(comments)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de récupération" })
  }
}

module.exports = { addComment, getTaskComments }
