const ProjectMember = require("../models/ProjectMember")
const User = require("../models/User")
const { fetchLog } = require("./LogController")

const addMember = async (req, res) => {
  try {
    const { user_id, related_user_id } = req.body

    if (!user_id || !related_user_id) {
      return res
        .status(400)
        .json({ message: "User ID et Related User ID requis" })
    }

    const member = await ProjectMember.create({ user_id, related_user_id })

    await fetchLog(
      `Ajout de membre: ${related_user_id} au chef de projet: ${user_id}`,
      "Ajout de membre",
      user_id
    )

    res.status(201).json(member)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur d'ajout de membre" })
  }
}

// Dans votre contrôleur
const getUserRelations = async (req, res) => {
  try {
    const relations = await ProjectMember.findAll({
      where: { user_id: req.params.owner_id },
      attributes: ["id", "user_id", "related_user_id"], // Champs conservés de ProjectMember
      include: [
        {
          model: User,
          as: "RelatedUser",
          attributes: ["name"], // <-- Seul le nom sera récupéré
        },
      ],
    })

    const simplifiedResponse = relations.map((relation) => ({
      id: relation.id,
      user_id: relation.related_user_id,
      member_name: relation.RelatedUser.name,
    }))

    res.status(200).json(simplifiedResponse)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de récupération des relations" })
  }
}

const deleteMember = async (req, res) => {
  try {
    const { id } = req.params
    const deleted = await ProjectMember.destroy({ where: { id } })

    if (deleted === 0) {
      return res.status(404).json({ message: "Relation non trouvée" })
    }

    res.status(200).json({ message: "Relation supprimée" })
    fetchLog(`Suppression de membre: ${id}`, "Suppression de membre", id)

    res.status(200).json({ message: "Membre supprimé" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de suppression" })
  }
}

module.exports = { addMember, getUserRelations, deleteMember }
