const Log = require("../models/Log")

const createNewLog = async (req, res) => {
  try {
    const { log_description, user_id, action } = req.body
    console.log(req.body)

    const newLog = await Log.create({ log_description, user_id, action })
    res.status(201).json(newLog)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}
const getAllLogs = async (req, res) => {
  try {
    const logs = await Log.findAll()
    res.status(200).json(logs)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}

const getLogsByUser = async (req, res) => {
  try {
    const logs = await Log.findAll({ where: { user_id: req.params.id } })
    res.status(200).json(logs)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}

const getLogsByDate = async (req, res) => {
  try {
    const logs = await Log.findAll({ where: { createdAt: req.params.date } })
    res.status(200).json(logs)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
}

const fetchLog = (log_description, action, user_id) => {
  return fetch("http://localhost:3000/api/logs", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ log_description, action, user_id }),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data)
    })
    .catch((error) => {
      console.error(error)
    })
}
const getAdminLogs = async (req, res) => {
  try {
      const adminLogs = await Log.findAll({
          where: {
              // Assuming your users table has a role field, otherwise adjust the query
              // to match what identifies an admin in your system
              // This could be done by joining with the Users table if needed
              [Op.or]: [
                  { user_id: { [Op.in]: await getUserIdsWithAdminRole() } },
                  { log_description: { [Op.like]: '%admin%' } },
                  { action: { [Op.like]: '%admin%' } }
              ]
          },
          order: [['createdAt', 'DESC']]
      });
      res.status(200).json(adminLogs);
  } catch (error) {
      res.status(500).json({ message: error.message });
  }
};

module.exports = { createNewLog, getAllLogs, getLogsByUser, getLogsByDate, fetchLog, getAdminLogs }
