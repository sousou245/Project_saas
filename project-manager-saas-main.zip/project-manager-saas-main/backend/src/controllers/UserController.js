const User = require("../models/User")
const { fetchLog } = require("./LogController")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
require("dotenv").config()

const createUser = async (req, res) => {
  try {
    console.log("Données reçues :", req.body)
    const { name, email, password, role } = req.body

    // Vérifier si l'utilisateur existe déjà
    const existingUser = await User.findOne({ where: { email } })
    if (existingUser) {
      return res.status(400).json({ message: "Utilisateur déjà existant" })
    }

    // Hacher le mot de passe
    const hashedPassword = await bcrypt.hash(password, 10)

    // Créer l'utilisateur
    const newUser = await User.create({
      name,
      email,
      password_hash: hashedPassword,
      role: role,
    })

    // Attendre que le log soit créé avant d'envoyer la réponse
    await fetchLog(
      `Ajout d'utilisateur: ${newUser.name}`,
      "Ajout d'utilisateur",
      newUser.id
    )

    // Envoyer la réponse après le log
    res.status(201).json({
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      role: newUser.role,
    })
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur de création", error: error.message })
  }
}

const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body

    // Trouver l'utilisateur
    const user = await User.findOne({ where: { email } })
    if (!user) {
      return res.status(404).json({ message: "Utilisateur non trouvé" })
    }

    // Vérifier le mot de passe
    const isMatch = await bcrypt.compare(password, user.password_hash)
    if (!isMatch) {
      return res.status(401).json({ message: "Mot de passe incorrect" })
    }

    // Générer le token JWT
    const token = jwt.sign(
      {
        id: user.id,
        nom: user.name,
        email: user.email,
        role: user.role,
      },
      process.env.JWT_SECRET,
      { expiresIn: "1h" }
    )

    await fetchLog(
      `Connexion de l'utilisateur: ${user.name}`,
      "Connexion d'utilisateur",
      user.id
    )

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur de connexion", error: error.message })
  }
}

const getCurrentUser = async (req, res) => {
  try {
    const userId = req.user.id

    const user = await User.findByPk(userId, {
      attributes: ["id", "name", "email", "role"],
    })

    if (!user) {
      return res.status(404).json({ message: "Utilisateur non trouvé" })
    }

    res.json(user)
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur de récupération", error: error.message })
  }
}

const getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: ["id", "name", "email", "role", "created_at"],
    })
    res.status(200).json(users)
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur de récupération", error: error.message })
  }
}

const getUserById = async (req, res) => {
  try {
    const { id } = req.params
    const user = await User.findByPk(id, {
      attributes: ["id", "name", "email", "role"],
    })
    res.status(200).json(user)
  } catch (error) {
    res
      .status(500)
      .json({ message: "Erreur de récupération", error: error.message })
  }
}

module.exports = {
  createUser,
  loginUser,
  getCurrentUser,
  getAllUsers,
  getUserById,
}
