const Task = require("../models/Task")
const User = require("../models/User")
const { fetchLog } = require("./LogController")

const createTask = async (req, res) => {
  try {
    const { title, project_id, description, priority, due_date } = req.body

    if (!title || !project_id || !description || !priority || !due_date) {
      return res.status(400).json({ message: "Champs requis manquants" })
    }

    const task = await Task.create({
      title,
      project_id,
      description,
      priority,
      status: "en_cours",
      due_date,
    })

    await fetchLog(
      `Ajout de tâche: ${task.title} au projet: ${task.project_id}`,
      "Ajout de tâche",
      task.project_id
    )

    res.status(201).json(task)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de création" })
  }
}

const updateTaskStatus = async (req, res) => {
  try {
    const { id } = req.params
    const { status } = req.body

    const [updated] = await Task.update({ status }, { where: { id } })

    if (updated === 0) {
      return res.status(404).json({ message: "Tâche non trouvée" })
    }

    await fetchLog(
      `Mise à jour de statut de tâche: ${id} \n Statut: ${status}`,
      "Mise à jour de statut de tâche",
      id
    )

    res.status(200).json({ message: "Statut mis à jour" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de mise à jour" })
  }
}

const getProjectTasks = async (req, res) => {
  try {
    const { project_id } = req.params
    const tasks = await Task.findAll({
      where: { project_id },
      include: [User],
    })
    res.status(200).json(tasks)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de récupération" })
  }
}

module.exports = { createTask, updateTaskStatus, getProjectTasks }
