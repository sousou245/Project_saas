const Project = require("../models/Project")
const { fetchLog } = require("./LogController")

const createProject = async (req, res) => {
  try {
    const { name, description, limite_date, owner_id, members } = req.body

    // Validation des champs requis
    if (!name || !owner_id) {
      return res.status(400).json({ message: "Nom et propriétaire requis" })
    }

    // Création du projet
    const project = await Project.create({
      name,
      description,
      limite_date,
      owner_id,
      create_at: new Date(),
      members: members || [], // Si 'members' n'est pas fourni, le champ sera un tableau vide
    })

    // Log de l'ajout du projet
    await fetchLog(
      `Ajout de projet: ${project.name}`,
      "Ajout de projet",
      owner_id
    )

    res.status(201).json(project)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de création" })
  }
}

const getProjects = async (req, res) => {
  try {
    const projects = await Project.findAll({
      include: [{ all: true }], // Inclut les relations
    })
    res.status(200).json(projects)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de récupération" })
  }
}

const deleteProject = async (req, res) => {
  try {
    const { id } = req.params
    const deleted = await Project.destroy({ where: { id } })

    if (deleted === 0) {
      return res.status(404).json({ message: "Projet non trouvé" })
    }

    // Log de la suppression
    await fetchLog(`Suppression de projet: ${id}`, "Suppression de projet", id)

    res.status(200).json({ message: "Projet supprimé" })
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de suppression" })
  }
}

const getProjectsByOwnerId = async (req, res) => {
  try {
    const { owner_id } = req.params
    const projects = await Project.findAll({
      where: { owner_id },
      include: [{ all: true }],
    })

    if (projects.length === 0) {
      return res.status(404).json({ message: "Aucun projet trouvé" })
    }

    res.status(200).json(projects)
  } catch (error) {
    console.error(error)
    res.status(500).json({ message: "Erreur de récupération" })
  }
}

module.exports = {
  createProject,
  getProjects,
  deleteProject,
  getProjectsByOwnerId,
}
