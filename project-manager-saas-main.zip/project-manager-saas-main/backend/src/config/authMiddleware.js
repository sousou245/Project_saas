const jwt = require("jsonwebtoken")
require("dotenv").config()

const authMiddleware = (req, res, next) => {
  // 1. Récupérer l'en-tête d'autorisation
  const authHeader = req.headers.authorization

  // 2. Vérifier si l'en-tête d'autorisation existe
  if (!authHeader) {
    return res.status(401).json({
      message: "Aucun token fourni",
      error: "Unauthorized",
    })
  }

  // 3. Extraire le token (enlever le préfixe "Bearer ")
  const token = authHeader.split(" ")[1]

  try {
    // 4. Vérifier et décoder le token
    const decoded = jwt.verify(token, process.env.JWT_SECRET)

    // 5. Ajouter les informations de l'utilisateur à la requête
    req.user = {
      id: decoded.id,
      nom: decoded.nom,
      email: decoded.email,
      role: decoded.role,
    }

    // 6. Passer au middleware suivant
    next()
  } catch (error) {
    // 7. Gestion des erreurs de token
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({
        message: "Token expiré",
        error: "Unauthorized",
      })
    }
    return res.status(403).json({
      message: "Token invalide",
      error: "Forbidden",
    })
  }
}

module.exports = authMiddleware
