require("dotenv").config()
const { Sequelize } = require("sequelize")

const sequelize = new Sequelize(
  process.env.DB_DATABASE,
  process.env.DB_USERNAME,
  process.env.DB_PASSWORD,
  {
    host: process.env.DB_HOST,
    dialect: process.env.DB_DIALECT,
    logging: false, // Désactive les logs SQL
  }
)

// Synchronisation simple des modèles
sequelize
  .sync({ force: false, alter: true })
  .then(() => console.log("✅ Tables synchronisées"))
  .catch((error) => console.error("❌ Erreur de sync:", error))

module.exports = sequelize
