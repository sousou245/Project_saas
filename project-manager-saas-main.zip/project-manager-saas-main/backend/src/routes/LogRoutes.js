const express = require("express")
const router = express.Router()
const {
  createNewLog,
  getAllLogs,
  getLogsByUser,
  getLogsByDate,
} = require("../controllers/LogController")

router.get("/logs", getAllLogs) //Validé
router.get("/users/:id/logs", getLogsByUser) //Validé
router.get("/logs/:date", getLogsByDate) //Validé
router.post("/logs", createNewLog) //Validé

module.exports = router
