const express = require("express")
const router = express.Router()
const {
  getCurrentUser,
  createUser,
  loginUser,
  getAllUsers,
  getUserById,
} = require("../controllers/UserController")
const authMiddleware = require("../config/authMiddleware")

router.post("/users", createUser)
router.get("/users", getAllUsers)
router.post("/login", loginUser)
router.get("/users/:id", getUserById)

router.get("/me", authMiddleware, getCurrentUser)

module.exports = router
