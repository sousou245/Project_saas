const express = require("express")
const router = express.Router()
const {
  addMember,
  getUserRelations,
  deleteMember,
} = require("../controllers/ProjectMemberController")

router.post("/project-members", addMember) //Validé
router.get("/projects/:owner_id/members", getUserRelations)
router.delete("/project-members/:id", deleteMember) //Validé

module.exports = router
