const express = require("express")
const router = express.Router()
const {
  createTask,
  updateTaskStatus,
  getProjectTasks,
} = require("../controllers/TaskController")

router.post("/tasks", createTask) //Validé
router.put("/tasks/:id/status", updateTaskStatus) //Validé
router.get("/projects/:project_id/tasks", getProjectTasks) //Validé

module.exports = router
