const express = require("express")
const router = express.Router()
const {
  createProject,
  getProjects,
  deleteProject,
  getProjectsByOwnerId,
} = require("../controllers/ProjectController")

router.post("/projects", createProject) //Validé
router.get("/projects", getProjects) //Validé
router.delete("/projects/:id", deleteProject) //Validé
router.get("/projects/:owner_id", getProjectsByOwnerId) //Validé

module.exports = router
