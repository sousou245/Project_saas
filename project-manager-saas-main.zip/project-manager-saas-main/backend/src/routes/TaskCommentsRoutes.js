const express = require("express")
const router = express.Router()
const {
  addComment,
  getTaskComments,
} = require("../controllers/TaskCommentsController")

router.post("/task-comments", addComment)
router.get("/tasks/:task_id/comments", getTaskComments)

module.exports = router
