const { DataTypes } = require("sequelize")
const sequelize = require("../config/database")
const User = require("./User")
const Project = require("./Project")

// Modèle Task
const Task = sequelize.define("Task", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: DataTypes.STRING,
  project_id: DataTypes.INTEGER,
  description: DataTypes.TEXT,
  priority: DataTypes.ENUM("basse", "moyenne", "haute"),
  status: DataTypes.ENUM("en_cours", "a_faire", "termine"),
  due_date: DataTypes.DATE,
  assigned_id: { type: DataTypes.INTEGER, allowNull: true },
})

// Relations directes
Task.belongsTo(Project, { foreignKey: "project_id", onDelete: "CASCADE" })
Task.belongsTo(User, { foreignKey: "assigned_id", onDelete: "CASCADE" })

Project.hasMany(Task, { foreignKey: "project_id", onDelete: "CASCADE" })
User.hasMany(Task, { foreignKey: "assigned_id", onDelete: "CASCADE" })

module.exports = Task
