const { DataTypes } = require("sequelize")
const  sequelize  = require("../config/database")
const User = require("./User")
const Task = require("./Task")

// Modèle TaskComment
const TaskComment = sequelize.define("TaskComment", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  task_id: DataTypes.INTEGER,
  user_id: DataTypes.INTEGER,
  content: DataTypes.TEXT,
  created_at: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
})

// Relations directes
TaskComment.belongsTo(Task, { foreignKey: "task_id", onDelete: "CASCADE" })
TaskComment.belongsTo(User, { foreignKey: "user_id", onDelete: "CASCADE" })

Task.hasMany(TaskComment, { foreignKey: "task_id", onDelete: "CASCADE" })
User.hasMany(TaskComment, { foreignKey: "user_id", onDelete: "CASCADE" })
