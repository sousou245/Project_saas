const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");
const User = require("./User");

// Modèle ProjectMember : lien entre deux utilisateurs
const ProjectMember = sequelize.define("ProjectMember", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  related_user_id: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});

// Relations avec User
ProjectMember.belongsTo(User, { foreignKey: "user_id", onDelete: "CASCADE" });
ProjectMember.belongsTo(User, { as: "RelatedUser", foreignKey: "related_user_id", onDelete: "CASCADE" });

// Relations inverses
User.hasMany(ProjectMember, { foreignKey: "user_id", onDelete: "CASCADE" });
User.hasMany(ProjectMember, { as: "RelatedUsers", foreignKey: "related_user_id", onDelete: "CASCADE" });

module.exports = ProjectMember;