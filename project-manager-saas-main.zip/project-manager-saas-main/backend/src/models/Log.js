const { DataTypes } = require("sequelize")
const sequelize = require("../config/database")

const Log = sequelize.define(
  "Log",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    log_description: DataTypes.STRING,
    user_id: DataTypes.INTEGER,
    action: DataTypes.STRING,
  },
  {
    timestamps: true,
    tableName: "logs",
  }
)

module.exports = Log